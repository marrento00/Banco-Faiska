package BackEnd;

public class ContaPoupanca extends ContaDeposito{

}
